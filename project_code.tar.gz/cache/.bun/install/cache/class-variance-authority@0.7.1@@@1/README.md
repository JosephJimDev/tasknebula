# class-variance-authority

For documentation, visit [cva.style](https://cva.style).
