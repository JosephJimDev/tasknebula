# Installation
> `npm install --save @types/d3-path`

# Summary
This package contains type definitions for d3-path (https://github.com/d3/d3-path/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-path.

### Additional Details
 * Last updated: Wed, 07 Feb 2024 18:07:36 GMT
 * Dependencies: none

# Credits
These definitions were written by [Tom Wanzek](https://github.com/tomwanzek), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), and [Nathan Bierema](https://github.com/Methuselah96).
