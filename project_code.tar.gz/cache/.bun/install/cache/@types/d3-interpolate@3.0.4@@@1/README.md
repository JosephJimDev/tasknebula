# Installation
> `npm install --save @types/d3-interpolate`

# Summary
This package contains type definitions for d3-interpolate (https://github.com/d3/d3-interpolate/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-interpolate.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 15:11:37 GMT
 * Dependencies: [@types/d3-color](https://npmjs.com/package/@types/d3-color)

# Credits
These definitions were written by [Tom Wanzek](https://github.com/tomwanzek), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [denisname](https://github.com/denisname), and [Nathan Bierema](https://github.com/Methuselah96).
