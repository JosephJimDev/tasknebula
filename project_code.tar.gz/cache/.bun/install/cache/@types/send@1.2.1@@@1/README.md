# Installation
> `npm install --save @types/send`

# Summary
This package contains type definitions for send (https://github.com/pillarjs/send).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/send.

### Additional Details
 * Last updated: Fri, 24 Oct 2025 04:02:41 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)

# Credits
These definitions were written by [Mike Jerred](https://github.com/MikeJerred), [Piotr Błażejewicz](https://github.com/peterblazejewicz), and [Sebastian Beltran](https://github.com/bjohansebas).
