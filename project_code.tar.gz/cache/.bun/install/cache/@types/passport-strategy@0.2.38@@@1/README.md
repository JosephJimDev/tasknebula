# Installation
> `npm install --save @types/passport-strategy`

# Summary
This package contains type definitions for passport-strategy (https://github.com/jaredhanson/passport-strategy).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/passport-strategy.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 09:09:39 GMT
 * Dependencies: [@types/express](https://npmjs.com/package/@types/express), [@types/passport](https://npmjs.com/package/@types/passport)

# Credits
These definitions were written by [Lior Mualem](https://github.com/liorm).
