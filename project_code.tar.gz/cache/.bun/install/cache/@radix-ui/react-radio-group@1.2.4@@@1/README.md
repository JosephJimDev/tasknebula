# `react-radio-group`

## Installation

```sh
$ yarn add @radix-ui/react-radio-group
# or
$ npm install @radix-ui/react-radio-group
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/radio-group).
