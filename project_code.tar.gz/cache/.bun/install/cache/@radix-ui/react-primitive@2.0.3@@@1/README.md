# `react-primitive`

## Installation

```sh
$ yarn add @radix-ui/react-primitive
# or
$ npm install @radix-ui/react-primitive
```

## Usage

This is an internal utility, not intended for public usage.
