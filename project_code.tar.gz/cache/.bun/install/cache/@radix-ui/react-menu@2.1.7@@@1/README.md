# `react-menu`

## Installation

```sh
$ yarn add @radix-ui/react-menu
# or
$ npm install @radix-ui/react-menu
```

## Usage

This is an internal utility, not intended for public usage.
