# `react-id`

## Installation

```sh
$ yarn add @radix-ui/react-id
# or
$ npm install @radix-ui/react-id
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/utilities/id-provider).
