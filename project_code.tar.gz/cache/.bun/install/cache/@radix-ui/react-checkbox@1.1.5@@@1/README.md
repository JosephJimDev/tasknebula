# `react-checkbox`

## Installation

```sh
$ yarn add @radix-ui/react-checkbox
# or
$ npm install @radix-ui/react-checkbox
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/checkbox).
