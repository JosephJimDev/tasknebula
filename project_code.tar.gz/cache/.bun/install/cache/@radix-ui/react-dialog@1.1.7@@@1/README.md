# `react-dialog`

## Installation

```sh
$ yarn add @radix-ui/react-dialog
# or
$ npm install @radix-ui/react-dialog
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/dialog).
