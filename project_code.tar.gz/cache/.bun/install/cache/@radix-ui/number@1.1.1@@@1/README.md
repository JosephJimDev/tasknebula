# `number`

## Installation

```sh
$ yarn add @radix-ui/number
# or
$ npm install @radix-ui/number
```

## Usage

This is an internal utility, not intended for public usage.
