# `react-popover`

## Installation

```sh
$ yarn add @radix-ui/react-popover
# or
$ npm install @radix-ui/react-popover
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/popover).
