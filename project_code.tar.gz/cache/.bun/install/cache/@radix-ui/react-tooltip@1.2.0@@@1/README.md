# `react-tooltip`

## Installation

```sh
$ yarn add @radix-ui/react-tooltip
# or
$ npm install @radix-ui/react-tooltip
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/tooltip).
