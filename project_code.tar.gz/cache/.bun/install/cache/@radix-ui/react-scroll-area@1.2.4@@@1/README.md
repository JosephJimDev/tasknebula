# `react-scroll-area`

## Installation

```sh
$ yarn add @radix-ui/react-scroll-area
# or
$ npm install @radix-ui/react-scroll-area
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/scroll-area).
