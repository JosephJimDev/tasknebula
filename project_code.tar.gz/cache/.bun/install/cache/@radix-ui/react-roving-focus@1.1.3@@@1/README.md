# `react-roving-focus`

## Installation

```sh
$ yarn add @radix-ui/react-roving-focus
# or
$ npm install @radix-ui/react-roving-focus
```

## Usage

This is an internal utility, not intended for public usage.
