# `react-separator`

## Installation

```sh
$ yarn add @radix-ui/react-separator
# or
$ npm install @radix-ui/react-separator
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/separator).
