export { UseEmblaCarouselType, EmblaViewportRefType } from './components/useEmblaCarousel';
export { default } from './components/useEmblaCarousel';
